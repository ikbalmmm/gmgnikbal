# 🤖 GMGN Auto-Trading Bot

Bot auto-trading meme coin Solana yang berjalan di atas **GMGN OpenAPI resmi**
(via `gmgn-cli`). Dua strategi bawaan:

1. **copy-smartmoney** (default) — beli token yang sedang diborong beberapa
   wallet Smart Money GMGN, lengkap dengan filter keamanan.
2. **trenches-snipe** — snipe token baru dari Trenches yang lolos preset
   filter GMGN (`safe` / `smart-money` / `strict`).

Setiap sinyal wajib lolos **vetting keamanan** sebelum beli: bukan honeypot,
`rug_ratio` rendah, pajak beli/jual wajar, likuiditas & holder cukup, market
cap dalam rentang. Exit otomatis: TP bertingkat, trailing stop, stop-loss,
exit saat smart money kabur, dan time-stop.

> ⚠️ **Bukan nasihat finansial.** Meme coin = risiko ekstrem (rug pull,
> volatilitas, likuiditas hilang). Bot ini alat, bukan mesin profit. Mulai
> dari PAPER TRADING dan dana kecil yang siap hilang.

## Biaya per trade (biar tidak kaget)

| Komponen | Besaran |
|---|---|
| Fee GMGN | **1%** saat beli + **1%** saat jual |
| Priority fee Solana | ~0.006 SOL/trade (agar eksekusi cepat) |
| Slippage | default 30% (meme coin bergerak liar) |

Artinya satu putaran beli-jual butuh naik **>2% + fee** cuma buat impas.

## Cara pakai

### 1. Install
```bash
npm install -g gmgn-cli        # CLI resmi GMGN (sudah terinstall di sini)
cd ~/workspace/gmgn-bot
cp config.example.yaml config.yaml
```

### 2. Dapatkan API key GMGN (gratis, untuk data & paper trading)
```bash
gmgn-cli config        # buka link yg muncul, buat API key di gmgn.ai
gmgn-cli config --apply <API_KEY_KAMU>
gmgn-cli config --check   # harus exit 0
```
🔑 API key & private key tersimpan di `~/.config/gmgn/.env` milikmu sendiri.
**Jangan pernah kirim ke siapa pun / paste di chat.**

### 3. Jalankan PAPER TRADING dulu (wajib)
```bash
python3 bot.py --once    # satu siklus, lihat sinyal & simulasi
python3 bot.py           # loop tiap 30 detik (Ctrl+C untuk berhenti)
```
Paper mode memakai harga asli via `order quote` + simulasi fee/slippage.
Tidak ada uang bergerak, tidak butuh private key.

### 4. (Opsional) Notifikasi Telegram
Buat bot via @BotFather, isi `telegram.bot_token` & `chat_id` di `config.yaml`.

### 5. Mode LIVE — hanya jika sudah paham risikonya
1. Siapkan **wallet khusus trading** (bukan wallet utama!), isi dana kecil
   (mis. 0.2–0.5 SOL untuk uji coba).
2. Ikat wallet itu ke API key GMGN, isi `trading.wallet_address` di config.
3. Kecilkan `trading.trade_size_sol` (mis. 0.02).
4. Jalankan dengan konfirmasi eksplisit ganda:
```bash
GMGN_LIVE_CONFIRM=I_UNDERSTAND_THE_RISK python3 bot.py --live
```

### Jalan 24/7 di VPS (disarankan)
Spek minimal: Ubuntu 24.04, 1 vCPU, 1 GB RAM (paket VPS termurah sudah cukup).
Upload `gmgn-bot.zip` ke VPS (mis. via SFTP di Termius), lalu:
```bash
unzip gmgn-bot.zip -d gmgn-bot && cd gmgn-bot
sudo bash deploy/install.sh
gmgn-cli config --apply <API_KEY_GMGN_KAMU>
nano /opt/gmgn-bot/config.yaml   # sesuaikan bila perlu
sudo systemctl start gmgn-bot    # jalan mode PAPER (simulasi)
sudo journalctl -u gmgn-bot -f   # pantau log
```
Service otomatis jalan lagi tiap VPS reboot.

Alternatif ringan tanpa systemd — cron tiap menit dengan `--once`:
```bash
* * * * * cd ~/workspace/gmgn-bot && python3 bot.py --once >> state/bot.log 2>&1
```

## Struktur

| File | Isi |
|---|---|
| `bot.py` | loop utama: sinyal → filter → eksekusi → kelola posisi |
| `gmgn.py` | wrapper `gmgn-cli` (data & trading) |
| `strategy.py` | strategi copy-smartmoney & trenches-snipe + vetting |
| `risk.py` | batas trade, rugi harian (auto-halt), cooldown |
| `executor.py` | PaperExecutor (simulasi) & LiveExecutor (uang asli) |
| `notify.py` | notifikasi Telegram |
| `state/` | posisi, saldo paper, PnL harian (otomatis dibuat) |
| `tests/test_logic.py` | smoke test tanpa network |

## Tips dari pengalaman umum trader GMGN

- Win rate 40–60% dari 50+ trade lebih bisa dipercaya daripada 90% dari 6 trade.
- Smart Money tag = dia profit *kemarin*, bukan jaminan dia tidak buang barang ke pengikutnya.
- Jangan kejar token yang sudah naik >5x dari sinyal — FOMO adalah donatur terbesar market.
- Copy trading GMGN resmi (di web/Telegram @GMGN_sol_bot) adalah alternatif
  tanpa coding — bandingkan dulu sebelum repot menjalankan bot sendiri.

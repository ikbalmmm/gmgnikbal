"""Notifikasi Telegram (opsional)."""
from __future__ import annotations

import requests


class Notifier:
    def __init__(self, cfg: dict):
        t = cfg.get("telegram", {}) or {}
        self.token = t.get("bot_token", "")
        self.chat_id = str(t.get("chat_id", ""))
        self.enabled = bool(self.token and self.chat_id)

    def send(self, text: str):
        if not self.enabled:
            return
        try:
            requests.post(
                f"https://api.telegram.org/bot{self.token}/sendMessage",
                json={"chat_id": self.chat_id, "text": text},
                timeout=10,
            )
        except Exception as e:  # notifikasi tidak boleh mematikan bot
            print(f"[notify] gagal kirim Telegram: {e}")

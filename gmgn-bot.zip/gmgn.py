"""Wrapper tipis di atas `gmgn-cli` resmi (GMGN OpenAPI).

Semua panggilan lewat subprocess. Tidak pernah mencetak API key / private key.
Fungsi yang butuh private key (swap, order strategy) hanya dipanggil dari
LiveExecutor yang mensyaratkan opt-in eksplisit.
"""
from __future__ import annotations

import json
import re
import subprocess
from typing import Any


class GMGNError(Exception):
    pass


def _extract_json(stdout: str) -> Any:
    """Coba parse stdout sebagai JSON; toleran terhadap teks pembungkus."""
    text = stdout.strip()
    if not text:
        raise GMGNError("Respons kosong dari gmgn-cli")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Cari blok JSON terbesar di dalam output
    match = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    raise GMGNError(f"Output gmgn-cli bukan JSON yang valid: {text[:200]}")


class GMGN:
    def __init__(self, timeout: int = 30):
        self.timeout = timeout

    # ---------- low level ----------
    def _run(self, *args: str) -> Any:
        cmd = ["gmgn-cli", *args]
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=self.timeout
            )
        except FileNotFoundError:
            raise GMGNError("gmgn-cli tidak ditemukan. Install: npm install -g gmgn-cli")
        except subprocess.TimeoutExpired:
            raise GMGNError(f"gmgn-cli timeout ({self.timeout}s): {' '.join(args[:3])}")

        out, err = proc.stdout.strip(), proc.stderr.strip()
        if proc.returncode != 0:
            msg = err or out or "unknown error"
            if "401" in msg or "403" in msg or "API Key" in msg or "api key" in msg.lower():
                raise GMGNError(
                    "API key GMGN belum valid/terkonfigurasi. Jalankan "
                    "`gmgn-cli config` lalu `gmgn-cli config --apply <API_KEY>`."
                )
            if "429" in msg or "RATE_LIMIT" in msg:
                raise GMGNError("Rate limit GMGN tercapai. Tunggu & coba lagi.")
            raise GMGNError(f"gmgn-cli gagal: {msg[:300]}")
        return _extract_json(out) if out else {}

    # ---------- setup ----------
    def config_check(self) -> bool:
        proc = subprocess.run(
            ["gmgn-cli", "config", "--check"], capture_output=True, text=True
        )
        return proc.returncode == 0

    # ---------- market data (API key saja, tanpa private key) ----------
    def smartmoney_trades(self, chain: str = "sol", limit: int = 100,
                          side: str | None = None) -> list[dict]:
        args = ["track", "smartmoney", "--chain", chain, "--limit", str(limit), "--raw"]
        if side:
            args += ["--side", side]
        data = self._run(*args)
        if isinstance(data, dict):
            # normalisasi: cari list di dalam respons
            for key in ("data", "trades", "list", "result"):
                if isinstance(data.get(key), list):
                    return data[key]
            return []
        return data if isinstance(data, list) else []

    def token_info(self, chain: str, address: str) -> dict:
        data = self._run("token", "info", "--chain", chain, "--address", address, "--raw")
        return data.get("data", data) if isinstance(data, dict) else {}

    def token_security(self, chain: str, address: str) -> dict:
        data = self._run("token", "security", "--chain", chain, "--address", address, "--raw")
        return data.get("data", data) if isinstance(data, dict) else {}

    def trenches(self, chain: str = "sol", preset: str = "smart-money",
                 limit: int = 40, **filters) -> list[dict]:
        args = ["market", "trenches", "--chain", chain,
                "--filter-preset", preset, "--limit", str(limit), "--raw"]
        for key, val in filters.items():
            args += [f"--{key.replace('_', '-')}", str(val)]
        data = self._run(*args)
        out: list[dict] = []
        if isinstance(data, dict):
            for cat in ("new_creation", "near_completion", "completed", "data", "list"):
                items = data.get(cat)
                if isinstance(items, list):
                    out.extend(items)
        elif isinstance(data, list):
            out = data
        return out

    def quote(self, chain: str, input_token: str, output_token: str,
              amount_smallest: int) -> dict:
        """Harga realistis tanpa eksekusi (tidak butuh private key)."""
        data = self._run(
            "order", "quote", "--chain", chain,
            "--input-token", input_token, "--output-token", output_token,
            "--amount", str(amount_smallest),
        )
        return data.get("data", data) if isinstance(data, dict) else {}

    # ---------- trading (BUTUH private key, hanya via LiveExecutor) ----------
    def swap(self, chain: str, wallet: str, input_token: str, output_token: str,
             amount_smallest: int | None = None, percent: int | None = None,
             slippage: int = 30, anti_mev: bool = True,
             condition_orders: list[dict] | None = None,
             priority_fee: float | None = None) -> dict:
        args = ["swap", "--chain", chain, "--from", wallet,
                "--input-token", input_token, "--output-token", output_token]
        if percent is not None:
            args += ["--percent", str(percent)]
        elif amount_smallest is not None:
            args += ["--amount", str(amount_smallest)]
        else:
            raise GMGNError("swap butuh --amount atau --percent")
        args += ["--slippage", str(slippage)]
        if anti_mev:
            args += ["--anti-mev"]
        if priority_fee:
            args += ["--priority-fee", str(priority_fee)]
        if condition_orders:
            args += ["--condition-orders", json.dumps(condition_orders)]
        args += ["--raw"]
        data = self._run(*args)
        return data.get("data", data) if isinstance(data, dict) else {}

    def order_status(self, chain: str, order_id: str) -> dict:
        data = self._run("order", "get", "--chain", chain, "--order-id", order_id)
        return data.get("data", data) if isinstance(data, dict) else {}

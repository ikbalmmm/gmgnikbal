"""Eksekusi trade: PaperExecutor (default, simulasi) dan LiveExecutor (opt-in).

PaperExecutor memakai `order quote` GMGN untuk harga realistis, menerapkan
slippage + fee 1% GMGN seperti aslinya, dan mencatat posisi di state/.

LiveExecutor HANYA aktif jika bot dijalankan dengan --live DAN env
GMGN_LIVE_CONFIRM=I_UNDERSTAND_THE_RISK. Ia memanggil `gmgn-cli swap`
dengan anti-MEV dan TP bertingkat, lalu stop-loss dikelola loop bot.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass

from gmgn import GMGN, GMGNError
from strategy import Signal

SOL_MINT = "So11111111111111111111111111111111111111112"
LAMPORTS = 1_000_000_000
GMGN_FEE = 0.01  # 1% per trade (buy & sell)


@dataclass
class Position:
    token: str
    symbol: str
    chain: str
    entry_price: float      # USD per token
    amount_token: float
    cost_sol: float
    opened_at: float
    tp1_done: bool = False
    stop_price: float = 0.0  # trailing stop dinamis
    order_id: str = ""       # live: id order GMGN

    def to_dict(self):
        return asdict(self)


class BaseExecutor:
    def __init__(self, gmgn: GMGN, cfg: dict, state_dir: str):
        self.gmgn = gmgn
        self.cfg = cfg
        self.state_dir = state_dir
        self.pos_path = os.path.join(state_dir, "positions.json")

    # ---- state posisi ----
    def load_positions(self) -> list[Position]:
        try:
            with open(self.pos_path) as f:
                return [Position(**p) for p in json.load(f)]
        except (FileNotFoundError, json.JSONDecodeError, TypeError):
            return []

    def save_positions(self, positions: list[Position]):
        os.makedirs(self.state_dir, exist_ok=True)
        with open(self.pos_path, "w") as f:
            json.dump([p.to_dict() for p in positions], f, indent=2)

    def buy(self, signal: Signal, size_sol: float) -> Position | None:
        raise NotImplementedError

    def sell(self, pos: Position, pct: int, reason: str) -> float:
        """Return PnL dalam SOL (positif/negatif)."""
        raise NotImplementedError

    def price(self, pos: Position) -> float:
        raise NotImplementedError


# ================= PAPER =================
class PaperExecutor(BaseExecutor):
    name = "paper"

    def __init__(self, gmgn: GMGN, cfg: dict, state_dir: str):
        super().__init__(gmgn, cfg, state_dir)
        self.balance = float(cfg.get("paper", {}).get("start_sol", 1.0))
        bal_path = os.path.join(state_dir, "paper_balance.json")
        try:
            with open(bal_path) as f:
                self.balance = float(json.load(f).get("sol", self.balance))
        except (FileNotFoundError, json.JSONDecodeError, ValueError):
            pass
        self.bal_path = bal_path

    def _save_balance(self):
        with open(self.bal_path, "w") as f:
            json.dump({"sol": round(self.balance, 6)}, f)

    def _quote_price(self, token: str, size_sol: float) -> float:
        """Harga token dalam USD via quote GMGN (SOL -> token)."""
        q = self.gmgn.quote(self.cfg.get("chain", "sol"), SOL_MINT, token,
                            int(size_sol * LAMPORTS))
        out = float(q.get("output_amount") or q.get("out_amount") or 0)
        dec = int(q.get("output_decimals") or q.get("out_decimals") or 9)
        if out <= 0:
            raise GMGNError("quote kosong (likuiditas mungkin nol)")
        # Terapkan slippage simulasi seperti setting live
        slip = self.cfg.get("trading", {}).get("slippage", 30) / 100
        tokens_received = (out / (10 ** dec)) * (1 - slip * 0.3)
        usd_per_sol = float(q.get("sol_price_usd") or q.get("solPriceUsd") or 0)
        if usd_per_sol <= 0:
            raise GMGNError("quote tanpa harga SOL/USD")
        usd_in = size_sol * usd_per_sol * (1 - GMGN_FEE)
        return usd_in / tokens_received  # USD per token

    def buy(self, signal: Signal, size_sol: float) -> Position | None:
        try:
            price = signal.price_usd or self._quote_price(signal.token_address, size_sol)
        except GMGNError as e:
            print(f"[paper] buy gagal (quote): {e}")
            return None
        if price <= 0:
            print("[paper] buy gagal: harga nol")
            return None
        sol_usd = self._sol_usd()
        usd_in = size_sol * sol_usd * (1 - GMGN_FEE)
        tokens = usd_in / price
        self.balance = round(self.balance - size_sol, 6)
        self._save_balance()
        t = self.cfg.get("trading", {})
        pos = Position(token=signal.token_address, symbol=signal.symbol,
                       chain=signal.chain, entry_price=price,
                       amount_token=tokens, cost_sol=size_sol,
                       opened_at=time.time(),
                       stop_price=price * (1 - t.get("stop_loss_pct", 35) / 100))
        print(f"[paper] BELI {signal.symbol} {size_sol} SOL @ ${price:.8f} "
              f"({tokens:,.0f} token) | {signal.reason}")
        return pos

    def _sol_usd(self) -> float:
        try:
            q = self.gmgn.quote(self.cfg.get("chain", "sol"), SOL_MINT, SOL_MINT, LAMPORTS)
            return float(q.get("sol_price_usd") or q.get("solPriceUsd") or 150)
        except GMGNError:
            return 150.0

    def sell(self, pos: Position, pct: int, reason: str) -> float:
        try:
            price = self.price(pos)
        except GMGNError as e:
            print(f"[paper] sell gagal (quote): {e}")
            return 0.0
        tokens_out = pos.amount_token * pct / 100
        usd_out = tokens_out * price * (1 - GMGN_FEE)
        sol_out = usd_out / self._sol_usd()
        cost_part = pos.cost_sol * pct / 100
        pnl = sol_out - cost_part
        pos.amount_token -= tokens_out
        pos.cost_sol = round(pos.cost_sol - cost_part, 6)
        self.balance = round(self.balance + sol_out, 6)
        self._save_balance()
        print(f"[paper] JUAL {pct}% {pos.symbol} @ ${price:.8f} | {reason} | "
              f"PnL {pnl:+.4f} SOL")
        return pnl

    def price(self, pos: Position) -> float:
        # quote balik: token -> SOL, lalu konversi ke USD via harga SOL
        info = self.gmgn.token_info(pos.chain, pos.token)
        p = float(info.get("price_usd") or info.get("price") or 0)
        if p <= 0:
            raise GMGNError("harga token tidak tersedia")
        return p


# ================= LIVE =================
LIVE_CONFIRM = "I_UNDERSTAND_THE_RISK"


class LiveExecutor(BaseExecutor):
    name = "live"

    def __init__(self, gmgn: GMGN, cfg: dict, state_dir: str):
        super().__init__(gmgn, cfg, state_dir)
        if os.environ.get("GMGN_LIVE_CONFIRM") != LIVE_CONFIRM:
            raise GMGNError(
                "Mode LIVE ditolak: set env GMGN_LIVE_CONFIRM=I_UNDERSTAND_THE_RISK "
                "untuk konfirmasi eksplisit."
            )
        if not gmgn.config_check():
            raise GMGNError("gmgn-cli belum dikonfigurasi (API key).")
        t = cfg.get("trading", {})
        self.wallet = t.get("wallet_address", "")
        if not self.wallet:
            raise GMGNError("trading.wallet_address kosong di config.")
        print("[LIVE] Mode LIVE aktif. Dana ASLI akan dipakai. "
              "Pastikan ini wallet khusus trading dengan dana kecil.")

    def buy(self, signal: Signal, size_sol: float) -> Position | None:
        t = self.cfg.get("trading", {})
        # TP bertingkat dipasang sekaligus via condition-orders GMGN
        cond = [
            {"order_type": "profit_stop", "side": "sell",
             "price_scale": str(t.get("tp1_scale", 200)),
             "sell_ratio": str(t.get("tp1_ratio", 50))},
            {"order_type": "profit_stop", "side": "sell",
             "price_scale": str(t.get("tp2_scale", 400)),
             "sell_ratio": "100"},
        ]
        try:
            res = self.gmgn.swap(
                self.cfg.get("chain", "sol"), self.wallet, SOL_MINT,
                signal.token_address, amount_smallest=int(size_sol * LAMPORTS),
                slippage=t.get("slippage", 30), anti_mev=True,
                condition_orders=cond,
                priority_fee=t.get("priority_fee_sol"),
            )
        except GMGNError as e:
            print(f"[LIVE] swap gagal: {e}")
            return None
        order_id = str(res.get("order_id") or res.get("orderId") or "")
        print(f"[LIVE] BELI {signal.symbol} {size_sol} SOL | order {order_id} | {signal.reason}")
        # Harga entry dibaca setelah order confirmed
        entry = signal.price_usd or 0.0
        try:
            info = self.gmgn.token_info(self.cfg.get("chain", "sol"), signal.token_address)
            entry = float(info.get("price_usd") or info.get("price") or entry)
        except GMGNError:
            pass
        sl_pct = t.get("stop_loss_pct", 35)
        return Position(token=signal.token_address, symbol=signal.symbol,
                        chain=signal.chain, entry_price=entry, amount_token=0,
                        cost_sol=size_sol, opened_at=time.time(),
                        stop_price=entry * (1 - sl_pct / 100), order_id=order_id)

    def sell(self, pos: Position, pct: int, reason: str) -> float:
        t = self.cfg.get("trading", {})
        try:
            res = self.gmgn.swap(
                self.cfg.get("chain", "sol"), self.wallet, pos.token, SOL_MINT,
                percent=pct, slippage=t.get("slippage", 30), anti_mev=True,
                priority_fee=t.get("priority_fee_sol"),
            )
            order_id = str(res.get("order_id") or res.get("orderId") or "")
            print(f"[LIVE] JUAL {pct}% {pos.symbol} | {reason} | order {order_id}")
        except GMGNError as e:
            print(f"[LIVE] sell gagal: {e}")
            return 0.0
        # PnL live dihitung dari perubahan harga (estimasi, bukan settlement)
        try:
            px = self.price(pos)
            usd_out = pos.amount_token * pct / 100 * px * (1 - GMGN_FEE)
            pnl = usd_out / 150 - pos.cost_sol * pct / 100  # estimasi kasar
        except GMGNError:
            pnl = 0.0
        pos.amount_token *= (1 - pct / 100)
        pos.cost_sol *= (1 - pct / 100)
        return pnl

    def price(self, pos: Position) -> float:
        info = self.gmgn.token_info(pos.chain, pos.token)
        p = float(info.get("price_usd") or info.get("price") or 0)
        if p <= 0:
            raise GMGNError("harga token tidak tersedia")
        return p


def build_executor(mode: str, gmgn: GMGN, cfg: dict, state_dir: str) -> BaseExecutor:
    if mode == "live":
        return LiveExecutor(gmgn, cfg, state_dir)
    return PaperExecutor(gmgn, cfg, state_dir)

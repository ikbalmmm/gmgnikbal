"""Manajemen risiko: semua trade harus lewat sini sebelum dieksekusi.

Batas yang ditegakkan:
- ukuran trade min/max
- maksimal posisi terbuka bersamaan
- maksimal kerugian harian -> bot berhenti total hari itu
- cooldown per token (tidak beli ulang token yang baru dijual)
- (live) saldo SOL cukup
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime


class RiskManager:
    def __init__(self, cfg: dict, state_dir: str):
        self.cfg = cfg.get("risk", {})
        self.state_dir = state_dir
        self.path = os.path.join(state_dir, "risk.json")
        self.state = self._load()

    def _load(self) -> dict:
        try:
            with open(self.path) as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"day": "", "day_pnl_sol": 0.0, "halted": False, "cooldowns": {}}

    def _save(self):
        os.makedirs(self.state_dir, exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(self.state, f, indent=2)

    def _new_day(self):
        today = datetime.now().strftime("%Y-%m-%d")
        if self.state.get("day") != today:
            self.state.update({"day": today, "day_pnl_sol": 0.0, "halted": False})
            self._save()

    def check_halt(self) -> tuple[bool, str]:
        self._new_day()
        if self.state.get("halted"):
            return True, "dihentikan: batas rugi harian tercapai"
        return False, ""

    def can_open(self, token: str, size_sol: float, open_positions: int,
                 balance_sol: float) -> tuple[bool, str]:
        halted, reason = self.check_halt()
        if halted:
            return False, reason
        r = self.cfg
        if not (r.get("min_trade_sol", 0.01) <= size_sol <= r.get("max_trade_sol", 0.2)):
            return False, f"ukuran {size_sol} SOL di luar batas"
        if open_positions >= r.get("max_positions", 3):
            return False, f"posisi penuh ({open_positions})"
        cd_until = self.state.get("cooldowns", {}).get(token, 0)
        if time.time() < cd_until:
            return False, "cooldown token"
        if balance_sol < size_sol + r.get("fee_reserve_sol", 0.02):
            return False, f"saldo {balance_sol:.3f} SOL tidak cukup"
        return True, "ok"

    def record_close(self, pnl_sol: float, token: str):
        self._new_day()
        self.state["day_pnl_sol"] = round(self.state.get("day_pnl_sol", 0.0) + pnl_sol, 6)
        cd_min = self.cfg.get("token_cooldown_min", 60)
        self.state.setdefault("cooldowns", {})[token] = time.time() + cd_min * 60
        if self.state["day_pnl_sol"] <= -abs(self.cfg.get("max_daily_loss_sol", 0.3)):
            self.state["halted"] = True
            print(f"[RISK] BATAS RUGI HARIAN TERCAPAI ({self.state['day_pnl_sol']:.3f} SOL). "
                  "Bot berhenti sampai besok.")
        self._save()

    def day_pnl(self) -> float:
        self._new_day()
        return self.state.get("day_pnl_sol", 0.0)

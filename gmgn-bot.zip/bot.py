#!/usr/bin/env python3
"""GMGN Auto-Trading Bot — copy-trade Smart Money / snipe Trenches.

DEFAULT: PAPER TRADING (simulasi, tanpa uang asli, tanpa private key).
Mode LIVE hanya dengan:  python bot.py --live
                        + env GMGN_LIVE_CONFIRM=I_UNDERSTAND_THE_RISK
                        + gmgn-cli terkonfigurasi + wallet_address di config.

Contoh:
    python bot.py --once                 # satu siklus paper (test cepat)
    python bot.py                        # loop paper terus-menerus
    python bot.py --strategy trenches-snipe --once
"""
from __future__ import annotations

import argparse
import sys
import time
from datetime import datetime

import yaml

from gmgn import GMGN, GMGNError
from strategy import build_strategy, Signal
from risk import RiskManager
from executor import build_executor, Position
from notify import Notifier


def log(msg: str):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def manage_positions(bot) -> None:
    """Cek TP/SL/trailing/time-stop untuk semua posisi terbuka."""
    t = bot.cfg.get("trading", {})
    positions = bot.executor.load_positions()
    if not positions:
        return
    kept: list[Position] = []
    for pos in positions:
        try:
            px = bot.executor.price(pos)
        except GMGNError as e:
            log(f"harga {pos.symbol} gagal: {e} (posisi ditahan)")
            kept.append(pos)
            continue
        chg = (px / pos.entry_price - 1) * 100 if pos.entry_price else 0

        # TP1: jual sebagian, stop digeser ke breakeven + trailing
        if not pos.tp1_done and chg >= t.get("tp1_pct", 100):
            pnl = bot.executor.sell(pos, t.get("tp1_ratio", 50), f"TP1 +{chg:.0f}%")
            pos.tp1_done = True
            pos.stop_price = pos.entry_price  # breakeven
            bot.risk.record_close(0, pos.token)  # cooldown dicatat saat full close
            bot.notify.send(f"✅ TP1 {pos.symbol}: +{chg:.0f}% (jual {t.get('tp1_ratio', 50)}%)")
        # Trailing stop setelah TP1
        if pos.tp1_done:
            trail = px * (1 - t.get("trailing_pct", 25) / 100)
            if trail > pos.stop_price:
                pos.stop_price = trail
        # TP2: habiskan
        if chg >= t.get("tp2_pct", 300):
            pnl = bot.executor.sell(pos, 100, f"TP2 +{chg:.0f}%")
            bot.risk.record_close(pnl, pos.token)
            bot.notify.send(f"🏁 TP2 {pos.symbol}: +{chg:.0f}% | PnL {pnl:+.4f} SOL")
            continue
        # Stop-loss
        if px <= pos.stop_price and pos.stop_price > 0:
            pnl = bot.executor.sell(pos, 100, f"STOP-LOSS {chg:.0f}%")
            bot.risk.record_close(pnl, pos.token)
            bot.notify.send(f"🛑 SL {pos.symbol}: {chg:.0f}% | PnL {pnl:+.4f} SOL")
            continue
        # Time stop
        age_h = (time.time() - pos.opened_at) / 3600
        if age_h >= t.get("max_hold_hours", 24):
            pnl = bot.executor.sell(pos, 100, f"time-stop {age_h:.1f} jam")
            bot.risk.record_close(pnl, pos.token)
            bot.notify.send(f"⏱️ Time-stop {pos.symbol}: {chg:+.0f}% | PnL {pnl:+.4f} SOL")
            continue
        kept.append(pos)
    bot.executor.save_positions(kept)


def smart_money_exits(bot) -> None:
    """Jual jika >= min_wallets smart-money menjual token yang kita pegang."""
    if bot.strategy.name != "copy-smartmoney":
        return
    c = bot.cfg.get("copy", {})
    need = c.get("exit_sell_wallets", 2)
    positions = bot.executor.load_positions()
    if not positions:
        return
    try:
        sells = bot.gmgn.smartmoney_trades(bot.cfg.get("chain", "sol"), limit=100, side="sell")
    except GMGNError:
        return
    sellers: dict[str, set] = {}
    for s in sells:
        tok = str(s.get("token_address") or s.get("tokenAddress") or s.get("mint") or "")
        w = str(s.get("wallet") or s.get("wallet_address") or s.get("tx_hash") or "")
        if tok:
            sellers.setdefault(tok, set()).add(w)
    kept: list[Position] = []
    for pos in positions:
        if len(sellers.get(pos.token, set())) >= need:
            try:
                pnl = bot.executor.sell(pos, 100, "smart money keluar")
            except GMGNError as e:
                log(f"gagal jual {pos.symbol}: {e}")
                kept.append(pos)
                continue
            bot.risk.record_close(pnl, pos.token)
            bot.notify.send(f"👋 Exit {pos.symbol}: smart money jual | PnL {pnl:+.4f} SOL")
        else:
            kept.append(pos)
    bot.executor.save_positions(kept)


def run_cycle(bot) -> None:
    halted, reason = bot.risk.check_halt()
    if halted:
        log(f"RISK HALT: {reason}")
        return
    # 1. Kelola posisi yang ada
    manage_positions(bot)
    smart_money_exits(bot)
    # 2. Cari sinyal baru
    try:
        signals = bot.strategy.poll()
    except GMGNError as e:
        log(f"poll sinyal gagal: {e}")
        return
    if signals:
        log(f"{len(signals)} sinyal: " + ", ".join(s.symbol for s in signals))
    positions = bot.executor.load_positions()
    held = {p.token for p in positions}
    for sig in signals:
        if sig.token_address in held:
            continue
        size = bot.cfg.get("trading", {}).get("trade_size_sol", 0.05)
        balance = getattr(bot.executor, "balance", 999.0)
        ok, why = bot.risk.can_open(sig.token_address, size, len(positions), balance)
        if not ok:
            log(f"skip {sig.symbol}: {why}")
            continue
        pos = bot.executor.buy(sig, size)
        if pos:
            positions.append(pos)
            bot.executor.save_positions(positions)
            bot.notify.send(
                f"🤖 {'[PAPER] ' if bot.mode == 'paper' else ''}BELI {sig.symbol} "
                f"{size} SOL\n{signal_reason(sig)}"
            )


def signal_reason(sig: Signal) -> str:
    return f"{sig.reason}\nCA: {sig.token_address}"


class Bot:
    def __init__(self, cfg: dict, mode: str, state_dir: str):
        self.cfg = cfg
        self.mode = mode
        self.gmgn = GMGN(timeout=cfg.get("gmgn_timeout", 30))
        self.strategy = build_strategy(cfg.get("strategy", "copy-smartmoney"),
                                       self.gmgn, cfg)
        self.risk = RiskManager(cfg, state_dir)
        self.executor = build_executor(mode, self.gmgn, cfg, state_dir)
        self.notify = Notifier(cfg)


def main():
    ap = argparse.ArgumentParser(description="GMGN auto-trading bot (default: paper)")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--strategy", choices=["copy-smartmoney", "trenches-snipe"])
    ap.add_argument("--live", action="store_true", help="MODE UANG ASLI (butuh konfirmasi env)")
    ap.add_argument("--once", action="store_true", help="satu siklus lalu berhenti")
    ap.add_argument("--interval", type=int, default=0, help="detik antar siklus (0=pakai config)")
    ap.add_argument("--state-dir", default="state")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.strategy:
        cfg["strategy"] = args.strategy
    mode = "live" if args.live else "paper"

    print("=" * 60)
    print(f"  GMGN Auto-Trading Bot  |  mode: {mode.upper()}  |  strategi: {cfg.get('strategy')}")
    if mode == "paper":
        print("  PAPER TRADING: simulasi, tidak ada uang asli bergerak.")
    print("=" * 60)

    try:
        bot = Bot(cfg, mode, args.state_dir)
    except GMGNError as e:
        print(f"FATAL: {e}")
        sys.exit(1)

    if not bot.gmgn.config_check():
        print("PERINGATAN: gmgn-cli belum dikonfigurasi (tanpa API key).")
        print("Data live butuh API key: jalankan `gmgn-cli config`, buka link yang")
        print("diberikan, buat API key di gmgn.ai, lalu `gmgn-cli config --apply <KEY>`.")
        if mode == "live":
            sys.exit(1)

    interval = args.interval or cfg.get("poll_interval_sec", 30)
    try:
        while True:
            run_cycle(bot)
            if args.once:
                break
            log(f"PnL hari ini: {bot.risk.day_pnl():+.4f} SOL | tidur {interval}s")
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nBerhenti. Posisi tersimpan di state/positions.json")


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# One-shot installer GMGN Auto-Trading Bot untuk VPS Ubuntu/Debian.
# Jalankan:  sudo bash deploy/install.sh   (dari folder hasil ekstrak zip)
set -euo pipefail

APP_DIR="/opt/gmgn-bot"
SERVICE="gmgn-bot"

echo "==> Install dependensi sistem..."
apt-get update -qq
apt-get install -y -qq python3 python3-yaml python3-requests nodejs npm unzip > /dev/null

echo "==> Install gmgn-cli (resmi GMGN)..."
npm install -g gmgn-cli > /dev/null 2>&1 || npm install -g gmgn-cli

echo "==> Salin file bot ke ${APP_DIR}..."
mkdir -p "${APP_DIR}/state"
cp bot.py gmgn.py strategy.py risk.py executor.py notify.py requirements.txt README.md "${APP_DIR}/"
[ -f "${APP_DIR}/config.yaml" ] || cp config.example.yaml "${APP_DIR}/config.yaml"
cp config.example.yaml "${APP_DIR}/"

echo "==> Pasang systemd service..."
cp deploy/gmgn-bot.service /etc/systemd/system/${SERVICE}.service
systemctl daemon-reload
systemctl enable ${SERVICE} > /dev/null

echo ""
echo "==============================================="
echo "  Instalasi selesai."
echo ""
echo "  Langkah berikutnya:"
echo "   1. gmgn-cli config --apply <API_KEY_GMGN_KAMU>"
echo "      (dapatkan API key gratis: jalankan 'gmgn-cli config', buka linknya)"
echo "   2. nano ${APP_DIR}/config.yaml   # sesuaikan bila perlu"
echo "   3. systemctl start ${SERVICE}    # bot jalan mode PAPER (simulasi)"
echo "   4. journalctl -u ${SERVICE} -f   # pantau log"
echo ""
echo "  Mode LIVE butuh wallet + konfirmasi eksplisit."
echo "  Baca README.md sebelum mengaktifkan."
echo "==============================================="

"""Smoke test logika bot TANPA network (FakeGMGN). Jalankan: python3 tests/test_logic.py"""
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import yaml
from gmgn import GMGNError
from risk import RiskManager
from executor import build_executor, PaperExecutor
from strategy import build_strategy, Signal
import bot as botmod


class FakeGMGN:
    """Meniru respons gmgn-cli dengan data tetap."""
    def __init__(self):
        self.price = 0.00001  # USD per token
        self.sol_usd = 150.0

    def config_check(self):
        return False

    def smartmoney_trades(self, chain="sol", limit=100, side=None):
        if side == "sell":
            return []
        now = time.time()
        return [
            {"tx_hash": "tx1", "token_address": "TOKEN123", "symbol": "MEME",
             "amount_usd": 500, "timestamp": now - 60, "wallet": "WALLET_A"},
            {"tx_hash": "tx2", "token_address": "TOKEN123", "symbol": "MEME",
             "amount_usd": 800, "timestamp": now - 120, "wallet": "WALLET_B"},
        ]

    def token_security(self, chain, address):
        return {"is_honeypot": False, "rug_ratio": 0.1, "buy_tax": 0, "sell_tax": 0}

    def token_info(self, chain, address):
        return {"price_usd": self.price, "liquidity": 50000,
                "holder_count": 200, "market_cap": 500000}

    def quote(self, chain, input_token, output_token, amount_smallest):
        return {"output_amount": str(int(1e12)), "output_decimals": 9,
                "sol_price_usd": self.sol_usd}


def make_bot(tmp):
    with open("config.example.yaml") as f:
        cfg = yaml.safe_load(f)
    b = botmod.Bot.__new__(botmod.Bot)
    b.cfg, b.mode = cfg, "paper"
    fake = FakeGMGN()
    b.gmgn = fake
    b.strategy = build_strategy("copy-smartmoney", fake, cfg)
    b.risk = RiskManager(cfg, tmp)
    b.executor = PaperExecutor(fake, cfg, tmp)
    from notify import Notifier
    b.notify = Notifier({})
    b.fake = fake
    return b


def test_risk(tmp):
    with open("config.example.yaml") as f:
        cfg = yaml.safe_load(f)
    r = RiskManager(cfg, tmp)
    ok, _ = r.can_open("T", 0.05, 0, 1.0)
    assert ok, "seharusnya boleh buka"
    ok, why = r.can_open("T", 5.0, 0, 1.0)
    assert not ok and "batas" in why, "trade kebesaran harus ditolak"
    ok, why = r.can_open("T", 0.05, 3, 1.0)
    assert not ok and "penuh" in why, "posisi penuh harus ditolak"
    r.record_close(-0.5, "T")  # tembus max_daily_loss 0.3
    halted, _ = r.check_halt()
    assert halted, "harus halt setelah rugi harian tembus batas"
    ok, _ = r.can_open("T2", 0.05, 0, 1.0)
    assert not ok, "tidak boleh buka saat halt"
    print("OK risk manager")


def test_live_guard(tmp):
    with open("config.example.yaml") as f:
        cfg = yaml.safe_load(f)
    try:
        build_executor("live", FakeGMGN(), cfg, tmp)
        raise AssertionError("live tanpa konfirmasi harus ditolak")
    except GMGNError as e:
        assert "LIVE_CONFIRM" in str(e) or "Mode LIVE" in str(e)
    print("OK live guard")


def test_full_cycle(tmp):
    b = make_bot(tmp)
    # Siklus 1: sinyal 2 wallet -> beli 1 posisi
    botmod.run_cycle(b)
    poss = b.executor.load_positions()
    assert len(poss) == 1, f"harusnya 1 posisi, dapat {len(poss)}"
    assert poss[0].symbol == "MEME"
    bal_after_buy = b.executor.balance
    assert bal_after_buy < 1.0, "saldo paper harus berkurang"
    # Siklus 2: harga naik 2.2x -> TP1 jual 50%, stop ke breakeven
    b.fake.price = poss[0].entry_price * 2.2
    botmod.run_cycle(b)
    poss = b.executor.load_positions()
    assert len(poss) == 1 and poss[0].tp1_done, "TP1 harus tereksekusi"
    assert poss[0].stop_price >= poss[0].entry_price, "stop minimal di breakeven"
    # Siklus 3: harga anjlok di bawah stop -> jual habis
    b.fake.price = poss[0].entry_price * 0.5
    botmod.run_cycle(b)
    poss = b.executor.load_positions()
    assert len(poss) == 0, "posisi harus habis terjual (stop)"
    # Cooldown: sinyal sama tidak boleh langsung dibeli lagi
    ok, why = b.risk.can_open("TOKEN123", 0.05, 0, 1.0)
    assert not ok and "cooldown" in why, "cooldown harus aktif"
    print("OK full cycle (sinyal -> beli -> TP1 -> stop)")


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    tmp = tempfile.mkdtemp(prefix="gmgn-test-")
    test_risk(tempfile.mkdtemp(prefix="gmgn-r"))
    test_live_guard(tempfile.mkdtemp(prefix="gmgn-l"))
    test_full_cycle(tmp)
    print("\nSemua smoke test lolos.")

"""Sumber sinyal trading.

Dua strategi tersedia (dipilih via config):
1. copy-smartmoney (default): ikuti pembelian wallet Smart Money GMGN.
   Sinyal muncul jika >= min_wallets wallet berbeda membeli token yang sama
   dalam jendela waktu, ATAU satu pembelian paus >= whale_buy_usd.
2. trenches-snipe: pindai token baru di Trenches dengan filter keamanan GMGN.

Setiap sinyal lolos vetting keamanan sebelum dieksekusi:
honeypot, rug_ratio, pajak beli/jual, likuiditas, jumlah holder, market cap.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from gmgn import GMGN, GMGNError


@dataclass
class Signal:
    token_address: str
    symbol: str = "?"
    chain: str = "sol"
    reason: str = ""
    price_usd: float = 0.0
    extra: dict = field(default_factory=dict)


def _f(val, default=0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _pick(d: dict, *keys, default=None):
    for k in keys:
        if isinstance(d, dict) and d.get(k) not in (None, ""):
            return d[k]
    return default


class BaseStrategy:
    name = "base"

    def __init__(self, gmgn: GMGN, cfg: dict):
        self.gmgn = gmgn
        self.cfg = cfg
        self.chain = cfg.get("chain", "sol")

    def poll(self) -> list[Signal]:
        raise NotImplementedError

    # ---------- vetting keamanan (dipakai semua strategi) ----------
    def vet(self, address: str) -> tuple[bool, str, dict]:
        """Return (lolos, alasan, info_token)."""
        s = self.cfg.get("safety", {})
        try:
            sec = self.gmgn.token_security(self.chain, address)
            info = self.gmgn.token_info(self.chain, address)
        except GMGNError as e:
            return False, f"cek keamanan gagal: {e}", {}

        if _pick(sec, "is_honeypot", "honeypot", default=False):
            return False, "honeypot terdeteksi", info
        rug = _f(_pick(sec, "rug_ratio", "rugRatio", default=0))
        if rug > s.get("max_rug_ratio", 0.3):
            return False, f"rug_ratio {rug:.2f} > batas", info
        buy_tax = _f(_pick(sec, "buy_tax", "buyTax", default=0))
        sell_tax = _f(_pick(sec, "sell_tax", "sellTax", default=0))
        if buy_tax > s.get("max_buy_tax", 10) or sell_tax > s.get("max_sell_tax", 10):
            return False, f"pajak {buy_tax:.0f}%/{sell_tax:.0f}% > batas", info

        liq = _f(_pick(info, "liquidity", "liquidity_usd", default=0))
        if liq < s.get("min_liquidity_usd", 20000):
            return False, f"likuiditas ${liq:,.0f} < minimum", info
        holders = int(_f(_pick(info, "holder_count", "holders", default=0)))
        if holders < s.get("min_holders", 50):
            return False, f"holder {holders} < minimum", info
        mcap = _f(_pick(info, "market_cap", "usd_market_cap", "fdv", default=0))
        if not (s.get("min_mcap_usd", 50000) <= mcap <= s.get("max_mcap_usd", 5_000_000)):
            return False, f"mcap ${mcap:,.0f} di luar rentang", info
        return True, "lolos", info


class CopySmartMoneyStrategy(BaseStrategy):
    """Copy trade: beli token yang diborong beberapa wallet Smart Money."""
    name = "copy-smartmoney"

    def __init__(self, gmgn: GMGN, cfg: dict):
        super().__init__(gmgn, cfg)
        self.seen_tx: set[str] = set()

    def poll(self) -> list[Signal]:
        c = self.cfg.get("copy", {})
        window = c.get("signal_window_min", 30) * 60
        min_wallets = c.get("min_wallets", 2)
        min_usd = c.get("min_signal_usd", 200)
        whale_usd = c.get("whale_buy_usd", 5000)
        now = time.time()

        try:
            trades = self.gmgn.smartmoney_trades(self.chain, limit=100, side="buy")
        except GMGNError as e:
            print(f"[strategi] gagal ambil smart money: {e}")
            return []

        # Kelompokkan pembelian per token dalam jendela waktu
        by_token: dict[str, dict] = {}
        for t in trades:
            tx = str(_pick(t, "tx_hash", "txHash", "hash", "signature", default=""))
            if tx and tx in self.seen_tx:
                continue
            token = str(_pick(t, "token_address", "tokenAddress", "mint", "address", default=""))
            if not token:
                continue
            usd = _f(_pick(t, "amount_usd", "usd_value", "value_usd", "volume_usd", default=0))
            if usd < min_usd:
                continue
            ts = _f(_pick(t, "timestamp", "time", "block_time", default=now))
            if now - ts > window:
                continue
            wallet = str(_pick(t, "wallet", "wallet_address", "from", default=""))
            bucket = by_token.setdefault(token, {"wallets": set(), "max_usd": 0.0,
                                                 "symbol": str(_pick(t, "symbol", "token_symbol", default="?"))})
            bucket["wallets"].add(wallet or tx)
            bucket["max_usd"] = max(bucket["max_usd"], usd)
            if tx:
                self.seen_tx.add(tx)

        signals: list[Signal] = []
        for token, b in by_token.items():
            n = len(b["wallets"])
            if n >= min_wallets or b["max_usd"] >= whale_usd:
                ok, reason, info = self.vet(token)
                if not ok:
                    print(f"[vetting] {token[:8]}... ditolak: {reason}")
                    continue
                price = _f(_pick(info, "price_usd", "price", default=0))
                signals.append(Signal(
                    token_address=token, symbol=b["symbol"], chain=self.chain,
                    reason=f"{n} smart-money beli (maks ${b['max_usd']:,.0f})",
                    price_usd=price,
                ))
        return signals


class TrenchesSnipeStrategy(BaseStrategy):
    """Snipe token baru dari Trenches yang lolos preset filter GMGN."""
    name = "trenches-snipe"

    def __init__(self, gmgn: GMGN, cfg: dict):
        super().__init__(gmgn, cfg)
        self.seen: set[str] = set()

    def poll(self) -> list[Signal]:
        c = self.cfg.get("snipe", {})
        max_age = c.get("max_age_min", 60) * 60
        now = time.time()
        try:
            tokens = self.gmgn.trenches(
                self.chain, preset=c.get("filter_preset", "smart-money"),
                limit=40, min_liquidity=c.get("min_liquidity_usd", 15000),
                max_rug_ratio=c.get("max_rug_ratio", 0.3),
                min_holder_count=c.get("min_holders", 30),
            )
        except GMGNError as e:
            print(f"[strategi] gagal ambil trenches: {e}")
            return []

        signals: list[Signal] = []
        for t in tokens:
            addr = str(_pick(t, "address", "token_address", "mint", default=""))
            if not addr or addr in self.seen:
                continue
            created = _f(_pick(t, "created_timestamp", "created_at", default=now))
            if created > 1e12:  # ms -> s
                created /= 1000
            if now - created > max_age:
                continue
            self.seen.add(addr)
            ok, reason, info = self.vet(addr)
            if not ok:
                print(f"[vetting] {addr[:8]}... ditolak: {reason}")
                continue
            signals.append(Signal(
                token_address=addr,
                symbol=str(_pick(t, "symbol", default="?")),
                chain=self.chain,
                reason=f"trenches baru ({(now - created) / 60:.0f} mnt)",
                price_usd=_f(_pick(t, "price_usd", "price", default=0)),
            ))
        return signals


def build_strategy(name: str, gmgn: GMGN, cfg: dict) -> BaseStrategy:
    if name == "trenches-snipe":
        return TrenchesSnipeStrategy(gmgn, cfg)
    return CopySmartMoneyStrategy(gmgn, cfg)
